import express from "express";

const app = express();
app.use(express.json({ limit: "32kb" }));

app.get("/", (_req, res) => res.json({ ok: true, service: "John AI APK Maker backend" }));

app.post("/generate", async (req, res) => {
  try {
    const idea = String(req.body?.idea || "").trim();
    if (!idea || idea.length > 5000) return res.status(400).json({ error: "Enter an app idea up to 5000 characters." });
    if (!process.env.OPENAI_API_KEY) return res.status(500).json({ error: "Server is missing OPENAI_API_KEY environment secret." });

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-6.1-sol",
        input: `You are John AI APK Maker, a helpful Android app planning and coding assistant. Turn this idea into a practical Android project plan. Include: app summary, screens, features, suggested Android architecture, file tree, key implementation steps, and a starter code example where useful. Be honest: this endpoint generates a plan and code guidance only; it does not compile an APK. Keep it safe and legal.\n\nAPP IDEA:\n${idea}`
      })
    });
    const data = await response.json();
    if (!response.ok) return res.status(response.status).json({ error: data?.error?.message || "OpenAI API request failed." });
    const result = (data.output || []).flatMap(item => item.content || [])
      .filter(part => part.type === "output_text").map(part => part.text).join("\n");
    res.json({ result: result || "No text was returned. Try a more detailed idea." });
  } catch (e) {
    res.status(500).json({ error: "Backend error: " + e.message });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`John AI backend listening on ${port}`));
