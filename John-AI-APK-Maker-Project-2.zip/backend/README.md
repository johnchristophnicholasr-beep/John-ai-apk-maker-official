# John AI APK Maker backend

This small Node.js server keeps the OpenAI API key on the server, not inside the Android APK.

## Run it
1. Install Node.js 20+.
2. In this folder run `npm install`.
3. Set the `OPENAI_API_KEY` environment variable in your hosting provider's secret/environment settings.
4. Optionally set `OPENAI_MODEL` to a model enabled for your API project.
5. Run `npm start`.
6. Use the HTTPS URL ending in `/generate` in the Android app.

Do not commit API keys to GitHub. OpenAI API usage may cost money and is separate from a ChatGPT subscription.

## Important limitation
This starter backend returns an app plan and code guidance. It does not build arbitrary user ideas into APKs. A full production APK maker also needs a secure isolated build worker that generates a complete Android project, validates it, runs Gradle, and provides a downloadable APK artifact. Do not compile untrusted generated code on a server without sandboxing and resource limits.
